import os
import platform
import sys
import threading
import time


class RestartApp:
    """
    Restart the current application.

    This sets a thread to run in the background so the calling method can complete its actions first.
    """

    def __init__(self, sleep_secs, start_file: str):
        """

        :param sleep_secs: how much time to sleep before restarting the application.
        :param start_file: The name to show in the thread.
        """
        self.sleep_secs = sleep_secs
        self.start_file = start_file
        thread = threading.Thread(target=self.run, name=f'Background restart.')
        thread.daemon = True
        thread.start()  # Start the execution with specified delay.

    def run(self):
        print(f'Sleeping {self.sleep_secs} seconds. {self.start_file}', flush=True)
        time.sleep(self.sleep_secs)
        system_name = platform.system()

        if system_name == 'Windows':
            print('Restarting on Windows', self.start_file, flush=True)
            os.execv(sys.executable, ['python'] + sys.argv)
        elif system_name == 'Darwin':
            # linux/mac
            print('Restarting on Mac', self.sleep_secs, flush=True)
            os.execv(self.start_file, sys.argv)
        else:
            print('Restarting on unidentified systems', self.start_file, flush=True)
            os.execv(self.start_file, sys.argv)
