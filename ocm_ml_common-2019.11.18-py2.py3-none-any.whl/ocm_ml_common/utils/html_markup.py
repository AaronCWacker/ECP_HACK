import glob
from flask import Markup


LOCAL_DATABASE_ENV = """<option value="stage" selected="selected">Stage</option>
                    <option value="prod">Production</option>"""

PROD_DATABASE_ENV = """<option value="stage">Stage</option>
                    <option value="prod" selected="selected">Production</option>"""


LOCAL_SERVERS = """<option value="127.0.0.1">Local Host</option>
                    <option value="10.201.144.167">Test weved23962</option>
                    <option value="10.50.8.130">Stage weves31263</option>
                    <option value="10.48.164.198">Prod wevep31172</option>"""


def env_options(ip_address: str) -> Markup:
    if ip_address == '10.48.164.198':
        return Markup(PROD_DATABASE_ENV)
    return Markup(LOCAL_DATABASE_ENV)


def server_options(ip_address:str) -> Markup:
    return Markup(LOCAL_SERVERS)


def sql_options(base_dir: str) -> [Markup, str]:
    """Create an option list based on files in the directory.
    
    :param base_dir: where the sql files are located  
    :return: list of options 
    """
    pattern = f'{base_dir}/*.sql'
    files = glob.glob(pattern, recursive=True)

    options = ''
    first = True
    first_file = ''
    for file in files:
        file = file.replace('\\', '/')
        description = file.replace('.sql', '').replace('_', ' ')
        last_count = description.rfind('/') + 1
        description = description[last_count:]
        # print(description)
        if first:
            options += f'<option value="{file}" selected="selected">{description}</option>\n'
            first_file = file
            first = False
        else:
            options += f'<option value="{file}">{description}</option>\n'
    return Markup(options), first_file


if __name__ == '__main__':
    print(sql_options('../sql/pa_related/care_guidance'))
