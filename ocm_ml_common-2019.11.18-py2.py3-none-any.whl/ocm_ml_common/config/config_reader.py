import configparser
import cryptography
import socket
from cryptography.fernet import Fernet
from pathlib import Path
from typing import NamedTuple, List


class OracleSettings(NamedTuple):
    schema: str
    database_name: str
    env: str
    host: str
    port: int
    sid: str
    dsn: bool
    user_name: str
    user_password: str
    pool_size: int


class ConfigParent:
    """Get settings.  The last file found wins. The file read in is
    of these formats in this order, when available
        <base_file_name>.ini
        <base_file_name>_<hostname>.ini
     where host is read from the os.environment.

     The encryption key is stored in
         <base_file_name>.key

    Keyword arguments:
    base_file_name - name of file
    """

    def __init__(self, base_file_name, path: str = ''):
        self.base_file_name = base_file_name
        self.path = path
        try:
            self._server_name = socket.gethostname()
        except KeyError:
            self._server_name = 'no_host_name'

        # must be last call
        self.config_parser = self._read_settings()
        self._create_or_read_key_file()

    @property
    def key_file_name(self) -> str:
        return f'{self.path}{self.base_file_name}_{self._server_name}.key'

    @property
    def server_ini_file_name(self) -> str:
        """Name of the user's settings based on machine name."""
        return f'{self.path}{self.base_file_name}_{self._server_name}.ini'

    @property
    def ini_files(self) -> list:
        """List of files to read options from.  The order is important since the last one read wins."""
        return [f'{self.path}{self.base_file_name}.ini', self.server_ini_file_name]

    def _read_settings(self) -> configparser.ConfigParser:
        """Read settings from a list of files.  Last file wins."""
        print('Key encryption file', self.key_file_name)
        print('Config files', self.ini_files)
        config_parser = configparser.ConfigParser()
        config_parser.read(self.ini_files)
        return config_parser

    def _encrypt(self, option_value: str) -> str:
        if option_value:
            text_bytes = option_value.encode()
            with open(self.key_file_name, 'rb') as f:
                key = f.read()  # The key will be type bytes
            f = Fernet(key)
            enc_text = f.encrypt(text_bytes)
            return enc_text.decode()
        return ''

    def _decrypt(self, option_value: str) -> str:
        if option_value:
            with open(self.key_file_name, 'rb') as f:
                key = f.read()  # The key will be type bytes
            f = Fernet(key)
            try:
                value = f.decrypt(option_value.encode())
                return value.decode()
            except cryptography.fernet.InvalidToken:
                pass
        return ''

    def _create_or_read_key_file(self) -> object:
        key_file = Path(self.key_file_name)
        if key_file.is_file():
            with open(self.key_file_name, 'rb') as f:
                key = f.read()  # The key will be type bytes
        else:
            print(f'Creating key file {self.key_file_name}')
            key = Fernet.generate_key()
            with open(self.key_file_name, 'wb') as f:
                f.write(key)  # The key is type bytes still

        return key

    def section_values(self, section_name) -> dict:
        options = self.config_parser.options(section_name)
        option_dict = {}
        for option in options:
            if str(option).startswith('bool.'):
                option_dict[option[5:]] = self.config_parser.getboolean(section_name, option)
            elif str(option).startswith('int.'):
                option_dict[option[4:]] = self.config_parser.getint(section_name, option)
            elif str(option).startswith('float.'):
                option_dict[option[6:]] = self.config_parser.getfloat(section_name, option)
            elif str(option).startswith('encrypt.'):
                value = self.config_parser.get(section_name, option, raw=True)
                new_value = self._decrypt(value)
                if not new_value:
                    print(f'Key file {self.key_file_name} could not decrypt "[{section_name}] {option}]". Encrypting')
                    new_value = value
                    self._encrypt_and_store_value(section_name, option, value)
                option_dict[option[8:]] = new_value
            else:
                option_dict[option] = self.config_parser.get(section_name, option)
        return option_dict

    def _encrypt_and_store_value(self, section_name: str, option: str, value: str):
        encrypted_value = self._encrypt(value)
        self.config_parser.set(section_name, option, encrypted_value)
        with open(self.server_ini_file_name, 'w') as configfile:
            self.config_parser.write(configfile)


class ConfigOracleDatabase(ConfigParent):
    def __init__(self, base_file_name: str = 'dbase_settings', path: str = ''):
        ConfigParent.__init__(self, base_file_name, path)

    def get_database_pool_settings(self) -> List[OracleSettings]:
        env = self.config_parser.get('base', 'env')
        oracle_pools = self.config_parser.get('base', 'oracle_pools')
        oracle_list = str(oracle_pools).split(' ')

        pools = []
        for item in oracle_list:
            section_name = f'{env}.oracle.{item}'
            setting_values = self.section_values(section_name)
            print(setting_values)
            pools.append(OracleSettings(
                database_name=item,
                env=env,
                schema=setting_values['schema'],
                host=setting_values['host'],
                port=setting_values['port'],
                sid=setting_values['sid'],
                dsn=setting_values['dsn'],
                user_name=setting_values['user_name'],
                user_password=setting_values['user_password'],
                pool_size=setting_values['pool_size']
            ))
        return pools


if __name__ == '__main__':
    my_parent = ConfigOracleDatabase(path='../')
    my_pool_settings = my_parent.get_database_pool_settings()
    print(my_pool_settings)
